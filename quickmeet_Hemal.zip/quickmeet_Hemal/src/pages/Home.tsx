import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Video, Users } from 'lucide-react';
import Navbar from '../components/Navbar';

export default function Home() {
  const [meetingCode, setMeetingCode] = useState('');
  const navigate = useNavigate();

  const createMeeting = () => {
    const meetingId = Math.random().toString(36).substring(2, 12);
    navigate(`/meeting/${meetingId}`);
  };

  const joinMeeting = () => {
    if (meetingCode.trim()) {
      navigate(`/meeting/${meetingCode}`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <Navbar />
      
      <main className="flex items-center justify-center min-h-screen">
        <div className="max-w-4xl w-full px-4 text-center">
          <motion.h1 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-6"
          >
            Video calls and meetings for everyone
          </motion.h1>
          
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600 dark:text-gray-300 mb-12"
          >
            Connect, collaborate, and celebrate with QuickMeet
          </motion.p>

          <div className="flex flex-col items-center gap-6 max-w-lg mx-auto">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
              onClick={createMeeting}
              className="w-full sm:w-64 px-8 py-4 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
            >
              <Video className="h-5 w-5" />
              <span>New Meeting</span>
            </motion.button>

            <div className="w-full flex flex-col sm:flex-row items-center gap-4 justify-center">
              <input
                type="text"
                value={meetingCode}
                onChange={(e) => setMeetingCode(e.target.value)}
                placeholder="Enter meeting code"
                className="w-full sm:w-96 px-6 py-4 rounded-full border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={joinMeeting}
                className="w-full sm:w-auto px-8 py-4 bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors flex items-center justify-center space-x-2"
              >
                <Users className="h-5 w-5" />
                <span>Join Meeting</span>
              </motion.button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}