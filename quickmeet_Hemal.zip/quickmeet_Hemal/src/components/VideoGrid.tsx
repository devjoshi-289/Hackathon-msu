import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';

const participants = [
  { id: 2, name: 'Alice Smith', image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=300&fit=crop' },
  { id: 3, name: 'Bob Johnson', image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=300&fit=crop' },
  { id: 4, name: 'Emma Wilson', image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=300&fit=crop' },
  { id: 5, name: 'Michael Brown', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop' },
  { id: 6, name: 'Sarah Davis', image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=300&fit=crop' }
];

interface VideoGridProps {
  isVideoOff: boolean;
}

export default function VideoGrid({ isVideoOff }: VideoGridProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);

  useEffect(() => {
    async function setupCamera() {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (err) {
        console.error('Error accessing camera:', err);
      }
    }

    setupCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  return (
    <div className="pt-20 pb-24 px-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-7xl mx-auto"
      >
        {/* User's own video */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="aspect-video bg-gray-800 rounded-xl overflow-hidden relative group"
        >
          {isVideoOff ? (
            <div className="w-full h-full flex items-center justify-center bg-gray-700">
              <span className="text-2xl font-bold text-gray-400">Camera Off</span>
            </div>
          ) : (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
          )}
          <motion.div 
            initial={{ opacity: 0 }}
            whileHover={{ opacity: 1 }}
            className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"
          />
          <div className="absolute bottom-4 left-4 flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full" />
            <span className="text-sm font-medium">You</span>
          </div>
        </motion.div>

        {/* Other participants */}
        {participants.map((participant, index) => (
          <motion.div
            key={participant.id}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            className="aspect-video bg-gray-800 rounded-xl overflow-hidden relative group"
          >
            <img 
              src={participant.image} 
              alt={participant.name}
              className="w-full h-full object-cover"
            />
            <motion.div 
              initial={{ opacity: 0 }}
              whileHover={{ opacity: 1 }}
              className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"
            />
            <div className="absolute bottom-4 left-4 flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">{participant.name}</span>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}