import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Mic, MicOff, Video, VideoOff, PhoneOff, Users, Share, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const participants = [
  { id: 1, name: 'DEV', image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=300&fit=crop' },
  { id: 2, name: 'JEET', image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=300&fit=crop' },
  { id: 3, name: 'HEMAL', image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=300&fit=crop' },
  { id: 4, name: 'DARSHAN', image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=300&fit=crop' },
  { id: 5, name: 'DARSHNA', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop' },
  { id: 6, name: 'PARUL UNIVERSITY', image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=300&fit=crop' }
];

export default function MeetingRoom() {
  const { id } = useParams();
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isChat, setIsChat] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      {/* Meeting Header */}
      <motion.div 
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="fixed top-0 left-0 right-0 bg-black/30 backdrop-blur-lg p-4 z-50"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-xl font-semibold">Meeting: {id}</h1>
          <div className="flex items-center space-x-4">
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="bg-gray-800/60 px-4 py-2 rounded-full flex items-center space-x-2"
            >
              <Users className="h-5 w-5" />
              <span>{participants.length}</span>
            </motion.div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsChat(!isChat)}
              className="bg-gray-800/60 p-2 rounded-full"
            >
              <MessageSquare className="h-5 w-5" />
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Video Grid */}
      <div className="pt-20 pb-24 px-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-7xl mx-auto"
        >
          {participants.map((participant, index) => (
            <motion.div
              key={participant.id}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              className="aspect-video bg-gray-800 rounded-xl overflow-hidden relative group"
            >
              <img 
                src={participant.image} 
                alt={participant.name}
                className="w-full h-full object-cover"
              />
              <motion.div 
                initial={{ opacity: 0 }}
                whileHover={{ opacity: 1 }}
                className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"
              />
              <div className="absolute bottom-4 left-4 flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-sm font-medium">{participant.name}</span>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Meeting Controls */}
      <motion.div 
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="fixed bottom-0 left-0 right-0 bg-black/30 backdrop-blur-lg p-6"
      >
        <div className="max-w-md mx-auto flex items-center justify-center space-x-4">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsMuted(!isMuted)}
            className={`p-4 rounded-full ${
              isMuted ? 'bg-red-500' : 'bg-gray-600'
            } hover:bg-opacity-80 transition-all duration-300 ease-in-out`}
          >
            {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsVideoOff(!isVideoOff)}
            className={`p-4 rounded-full ${
              isVideoOff ? 'bg-red-500' : 'bg-gray-600'
            } hover:bg-opacity-80 transition-all duration-300 ease-in-out`}
          >
            {isVideoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="p-4 rounded-full bg-gray-600 hover:bg-opacity-80 transition-all duration-300 ease-in-out"
          >
            <Share className="h-6 w-6" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="p-4 rounded-full bg-red-500 hover:bg-red-600 transition-all duration-300 ease-in-out"
          >
            <PhoneOff className="h-6 w-6" />
          </motion.button>
        </div>
      </motion.div>

      {/* Chat Sidebar */}
      <AnimatePresence>
        {isChat && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 20 }}
            className="fixed top-0 right-0 w-80 h-full bg-gray-800 shadow-xl z-40 p-4"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Chat</h2>
              <button onClick={() => setIsChat(false)} className="text-gray-400 hover:text-white">
                ✕
              </button>
            </div>
            <div className="space-y-4">
              {/* Chat messages would go here */}
              <p className="text-gray-400 text-center text-sm">No messages yet</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}