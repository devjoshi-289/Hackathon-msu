import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, MessageSquare } from 'lucide-react';
import VideoGrid from '../components/VideoGrid';
import Controls from '../components/Controls';
import ChatSidebar from '../components/ChatSidebar';

export default function MeetingRoom() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isChat, setIsChat] = useState(false);

  const handleEndCall = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      {/* Meeting Header */}
      <motion.div 
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="fixed top-0 left-0 right-0 bg-black/30 backdrop-blur-lg p-4 z-50"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-xl font-semibold">Meeting: {id}</h1>
          <div className="flex items-center space-x-4">
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="bg-gray-800/60 px-4 py-2 rounded-full flex items-center space-x-2"
            >
              <Users className="h-5 w-5" />
              <span>6</span>
            </motion.div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsChat(!isChat)}
              className="bg-gray-800/60 p-2 rounded-full"
            >
              <MessageSquare className="h-5 w-5" />
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Video Grid */}
      <VideoGrid isVideoOff={isVideoOff} />

      {/* Meeting Controls */}
      <Controls 
        isMuted={isMuted}
        isVideoOff={isVideoOff}
        onToggleMute={() => setIsMuted(!isMuted)}
        onToggleVideo={() => setIsVideoOff(!isVideoOff)}
        onEndCall={handleEndCall}
      />

      {/* Chat Sidebar */}
      <ChatSidebar isOpen={isChat} onClose={() => setIsChat(false)} />
    </div>
  );
}