import { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import MeetingRoom from './pages/MeetingRoom';
import { ThemeProvider } from './contexts/ThemeContext';

function App() {
  const [isDarkMode, setIsDarkMode] = useState(false);

  return (
    <ThemeProvider>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/meeting/:id" element={<MeetingRoom />} />
      </Routes>
    </ThemeProvider>
  );
}

export default App;