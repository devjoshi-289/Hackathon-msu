import { motion } from 'framer-motion';
import { Mic, MicOff, Video, VideoOff, PhoneOff, Share } from 'lucide-react';

interface ControlsProps {
  isMuted: boolean;
  isVideoOff: boolean;
  onToggleMute: () => void;
  onToggleVideo: () => void;
  onEndCall: () => void;
}

export default function Controls({ isMuted, isVideoOff, onToggleMute, onToggleVideo, onEndCall }: ControlsProps) {
  return (
    <motion.div 
      initial={{ y: 50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed bottom-0 left-0 right-0 bg-black/30 backdrop-blur-lg p-6"
    >
      <div className="max-w-md mx-auto flex items-center justify-center space-x-6">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onToggleMute}
          className={`p-4 rounded-full ${
            isMuted ? 'bg-red-500' : 'bg-gray-600'
          } hover:bg-opacity-80 transition-all duration-300 ease-in-out`}
        >
          {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
        </motion.button>
        
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onToggleVideo}
          className={`p-4 rounded-full ${
            isVideoOff ? 'bg-red-500' : 'bg-gray-600'
          } hover:bg-opacity-80 transition-all duration-300 ease-in-out`}
        >
          {isVideoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="p-4 rounded-full bg-gray-600 hover:bg-opacity-80 transition-all duration-300 ease-in-out"
        >
          <Share className="h-6 w-6" />
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onEndCall}
          className="p-4 rounded-full bg-red-500 hover:bg-red-600 transition-all duration-300 ease-in-out"
        >
          <PhoneOff className="h-6 w-6" />
        </motion.button>
      </div>
    </motion.div>
  );
}